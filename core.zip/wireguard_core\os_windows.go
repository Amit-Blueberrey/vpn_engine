//go:build windows
package main

import (
	"golang.zx2c4.com/wireguard/device"
	"golang.zx2c4.com/wireguard/tun"
	"net"
)

func createTunDevice(name string, mtu int, platformFd int) (tun.Device, error) {
	return tun.CreateTUN(name, mtu)
}

func setupUAPI(name string, dev *device.Device) net.Listener {
	return nil
}
